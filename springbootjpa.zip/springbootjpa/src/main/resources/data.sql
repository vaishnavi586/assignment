insert into alien values (101,'vaishu','java');
insert into alien values (102,'nikki','java');
insert into alien values (103,'alekya','python');
insert into alien values (104,'yamini','c');
insert into alien values (105,'shruti','python');