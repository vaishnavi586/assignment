package com.springboot.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.springboot.demo.model.Alien;

public interface AlienRepo extends CrudRepository<Alien, Integer> {
	
	

}
